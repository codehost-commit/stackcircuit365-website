"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

const VALID_KEY = "12345678";

const SEVERITY = {
  ok: { color: "#0f7a3d", label: "Operational", note: "All checks passing" },
  minor: { color: "#9a7d0a", label: "Minor", note: "Elevated errors" },
  major: { color: "#b5651d", label: "Major", note: "Degraded service" },
  critical: { color: "#b42318", label: "Critical", note: "Outage in progress" }
} as const;

type Sev = keyof typeof SEVERITY;
const SEV_ORDER: Sev[] = ["ok", "minor", "major", "critical"];

// Hardcoded, matches the example production panel on the home page.
const severity: Sev = "ok";

const statRows: [string, string][] = [
  ["status", "HEALTHY // 12 of 12 checks passing"],
  ["deploy", "dpl_9f21c  promoted 4m ago"],
  ["commit", 'a1b2c3d  "fix: cache-control header"'],
  ["latency", "p95 210ms // no error spike"],
  ["known good", "dpl_9f21c  verified and locked"]
];

const signals: [string, string][] = [
  ["Error rate", "0.02% // baseline 0.03%"],
  ["Latency p95", "210ms // baseline 240ms"],
  ["Availability", "100% over the last 30m"],
  ["Error budget", "99.6% remaining"]
];

const incidents = [
  {
    id: "inc_20260904",
    kind: "release regression",
    sev: "major" as const,
    status: "recovered",
    conf: "0.93",
    action: "rolled back",
    target: "dpl_6b0f9"
  }
];

const deploys = [
  { id: "dpl_9f21c", commit: 'a1b2c3d "fix: cache-control header"', state: "LIVE", tone: "ok", when: "4m ago" },
  { id: "dpl_7c33a", commit: 'e9f14a2 "add pricing table query"', state: "REVERTED", tone: "bad", when: "18m ago" },
  { id: "dpl_6b0f9", commit: 'c4d5e6f "tune ISR cache"', state: "KNOWN-GOOD", tone: "ok", when: "2h ago" }
];

const gates = [
  "You opted into auto-recovery",
  "A production deploy happened recently",
  "The previous deployment is verified healthy",
  "Multiple consecutive checks are failing",
  "Failure began shortly after the deploy",
  "The app is clearly erroring or unreachable",
  "No known external dependency outage",
  "No migration, auth, billing, or secret change",
  "No incident lock is active",
  "High confidence the deploy caused it"
];

const alertsFeed = [
  { t: "14:05:38", text: "Recovery verified for inc_20260904", tone: "ok" },
  { t: "14:04:20", text: "Rollback recommended to dpl_6b0f9", tone: "warn" },
  { t: "14:04:05", text: "Incident opened, confidence 0.93", tone: "bad" },
  { t: "14:02:11", text: "Deployment dpl_7c33a promoted to production", tone: "muted" }
];

const NAV = ["Home", "Status", "Incidents", "Deploys", "Policy", "Alerts", "Settings"];

function toneColor(tone: string) {
  return tone === "ok"
    ? "#0f7a3d"
    : tone === "warn"
    ? "#a15c00"
    : tone === "bad"
    ? "#b42318"
    : "#5c5f66";
}

function Panel({
  label,
  children
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="border border-line bg-card">
      <div className="border-b border-line2 px-4 py-2.5">
        <span className="font-mono text-[11px] uppercase tracking-widest text-muted">
          {label}
        </span>
      </div>
      <div>{children}</div>
    </div>
  );
}

function StatusBox() {
  const s = SEVERITY[severity];
  return (
    <div>
      <div className="border border-line" style={{ backgroundColor: s.color }}>
        <div className="p-8">
          <span className="font-mono text-[11px] uppercase tracking-widest text-paper/80">
            System status
          </span>
          <div className="mt-3 text-4xl font-semibold text-paper">{s.label}</div>
          <div className="mt-3 font-mono text-[13px] text-paper/90">
            production // app.example.dev
          </div>
          <div className="mt-1 font-mono text-[13px] text-paper/90">
            {s.note} // p95 210ms
          </div>
        </div>
      </div>
      <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2">
        {SEV_ORDER.map((k) => (
          <span
            key={k}
            className="flex items-center gap-2 font-mono text-[11px] text-muted"
          >
            <span
              className="h-2.5 w-2.5"
              style={{ backgroundColor: SEVERITY[k].color }}
            />
            {SEVERITY[k].label}
          </span>
        ))}
      </div>
    </div>
  );
}

function StatRowsPanel() {
  return (
    <Panel label="production // app.example.dev">
      <dl className="divide-y divide-line2 font-mono text-[13px]">
        {statRows.map(([k, v]) => (
          <div key={k} className="grid grid-cols-[7rem_1fr] gap-3 px-4 py-3">
            <dt className="pt-0.5 text-[11px] uppercase tracking-widest text-muted">
              {k}
            </dt>
            <dd className="text-ink">{v}</dd>
          </div>
        ))}
      </dl>
      <div className="border-t border-line2 px-4 py-3">
        <span className="font-mono text-[11px] text-muted">
          Next check in 41s. Post-deploy window closes in 9m.
        </span>
      </div>
    </Panel>
  );
}

function IncidentsTable() {
  return (
    <Panel label="Incidents">
      <div className="overflow-x-auto">
        <table className="w-full border-collapse font-mono text-[12px]">
          <thead>
            <tr className="border-b border-line2 text-left text-muted">
              {["ID", "Kind", "Severity", "Status", "Conf.", "Action", "Target"].map(
                (h) => (
                  <th
                    key={h}
                    className="px-4 py-2.5 text-[11px] uppercase tracking-widest"
                  >
                    {h}
                  </th>
                )
              )}
            </tr>
          </thead>
          <tbody>
            {incidents.map((i) => (
              <tr key={i.id} className="border-b border-line2 text-ink">
                <td className="px-4 py-3">{i.id}</td>
                <td className="px-4 py-3">{i.kind}</td>
                <td className="px-4 py-3">
                  <span style={{ color: toneColor("warn") }}>{i.sev}</span>
                </td>
                <td className="px-4 py-3">
                  <span style={{ color: toneColor("ok") }}>{i.status}</span>
                </td>
                <td className="px-4 py-3">{i.conf}</td>
                <td className="px-4 py-3">{i.action}</td>
                <td className="px-4 py-3">{i.target}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="border-t border-line2 px-4 py-3">
        <span className="font-mono text-[11px] text-muted">
          No active incidents. All clear.
        </span>
      </div>
    </Panel>
  );
}

function DeploysList() {
  return (
    <Panel label="Deployments">
      <div className="divide-y divide-line2">
        {deploys.map((d) => (
          <div
            key={d.id}
            className="grid grid-cols-1 gap-2 px-4 py-4 md:grid-cols-[10rem_1fr_auto] md:items-center"
          >
            <span className="font-mono text-[13px] text-ink">{d.id}</span>
            <span className="font-mono text-[12px] text-muted">{d.commit}</span>
            <div className="flex items-center gap-4">
              <span className="font-mono text-[11px] text-muted">{d.when}</span>
              <span
                className="font-mono text-[11px] uppercase tracking-widest"
                style={{ color: toneColor(d.tone) }}
              >
                {d.state}
              </span>
            </div>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function SignalsPanel() {
  return (
    <Panel label="Health signals">
      <div className="divide-y divide-line2 font-mono text-[13px]">
        {signals.map(([k, v]) => (
          <div
            key={k}
            className="flex items-center justify-between gap-4 px-4 py-3"
          >
            <span className="flex items-center gap-3 text-ink">
              <span className="h-2 w-2 bg-signal" />
              {k}
            </span>
            <span className="text-muted">{v}</span>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function TabContent({ tab }: { tab: string }) {
  if (tab === "Home") {
    return (
      <div className="flex flex-col gap-6">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_1.35fr]">
          <StatusBox />
          <StatRowsPanel />
        </div>
        <IncidentsTable />
        <DeploysList />
      </div>
    );
  }
  if (tab === "Status") {
    return (
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_1.35fr]">
        <StatusBox />
        <SignalsPanel />
      </div>
    );
  }
  if (tab === "Incidents") return <IncidentsTable />;
  if (tab === "Deploys") return <DeploysList />;
  if (tab === "Policy") {
    return (
      <div className="flex flex-col gap-6">
        <Panel label="Recovery policy">
          <div className="flex flex-col gap-3 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
            <span className="font-mono text-[13px] text-ink">
              Mode: Approval Required
            </span>
            <span className="font-mono text-[11px] uppercase tracking-widest text-signal">
              Automation pause // off
            </span>
          </div>
        </Panel>
        <Panel label="Auto-recover gates (all ten must pass)">
          <ul className="divide-y divide-line2">
            {gates.map((g, i) => (
              <li
                key={g}
                className="flex items-center gap-3 px-4 py-3 font-mono text-[13px] text-ink"
              >
                <span className="text-muted">
                  {(i + 1).toString().padStart(2, "0")}
                </span>
                <span className="h-1.5 w-1.5 bg-signal" />
                {g}
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    );
  }
  if (tab === "Alerts") {
    return (
      <div className="flex flex-col gap-6">
        <Panel label="Destinations">
          <div className="divide-y divide-line2 font-mono text-[13px]">
            <div className="flex items-center justify-between px-4 py-3">
              <span className="text-ink">Email</span>
              <span className="text-muted">you@example.dev</span>
            </div>
            <div className="flex items-center justify-between px-4 py-3">
              <span className="text-ink">Slack</span>
              <span className="text-muted">#deploys</span>
            </div>
            <div className="flex items-center justify-between px-4 py-3">
              <span className="text-ink">GitHub issues</span>
              <span className="text-muted">opt-in // off</span>
            </div>
          </div>
        </Panel>
        <Panel label="Recent alerts">
          <ul className="divide-y divide-line2">
            {alertsFeed.map((a) => (
              <li
                key={a.t}
                className="flex items-center gap-4 px-4 py-3 font-mono text-[13px]"
              >
                <span className="text-muted tabular-nums">{a.t}</span>
                <span
                  className="h-2 w-2 shrink-0"
                  style={{ backgroundColor: toneColor(a.tone) }}
                />
                <span className="text-ink">{a.text}</span>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    );
  }
  // Settings
  return (
    <div className="flex flex-col gap-6">
      <Panel label="Connection">
        <div className="divide-y divide-line2 font-mono text-[13px]">
          {[
            ["Repository", "you/app"],
            ["Vercel project", "prj_9Xk2 (production)"],
            ["Production URL", "https://app.example.dev"],
            ["Health endpoint", "/api/health"],
            ["Recovery mode", "Approval Required"],
            ["Console key", "xxxx xxxx 5678"]
          ].map(([k, v]) => (
            <div
              key={k}
              className="grid grid-cols-[9rem_1fr] gap-3 px-4 py-3"
            >
              <span className="text-[11px] uppercase tracking-widest text-muted">
                {k}
              </span>
              <span className="text-ink">{v}</span>
            </div>
          ))}
        </div>
      </Panel>
      <Panel label="Connect the module">
        <div className="px-4 py-4 font-mono text-[12px] leading-relaxed text-muted">
          <div className="text-ink">$ npm i stackcircuit365</div>
          <div className="mt-1">
            $ stackcircuit365-serve --url https://app.example.dev --key 12345678
          </div>
          <div className="mt-2">
            The service pushes live status to this dashboard for your key.
          </div>
        </div>
      </Panel>
    </div>
  );
}

export default function Dashboard() {
  const [mounted, setMounted] = useState(false);
  const [authed, setAuthed] = useState(false);
  const [keyInput, setKeyInput] = useState("");
  const [error, setError] = useState("");
  const [tab, setTab] = useState("Home");

  useEffect(() => {
    setMounted(true);
    let saved = "";
    try {
      const q = new URLSearchParams(window.location.search).get("key");
      saved = q || window.sessionStorage.getItem("sc_key") || "";
    } catch (e) {
      saved = "";
    }
    if (saved === VALID_KEY) setAuthed(true);
  }, []);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (keyInput.trim() === VALID_KEY) {
      setAuthed(true);
      setError("");
      try {
        window.sessionStorage.setItem("sc_key", VALID_KEY);
      } catch (err) {
        /* ignore */
      }
    } else {
      setError("That console key is not recognized.");
    }
  }

  function signOut() {
    setAuthed(false);
    setKeyInput("");
    try {
      window.sessionStorage.removeItem("sc_key");
    } catch (err) {
      /* ignore */
    }
  }

  if (!mounted) {
    return <div className="min-h-[60vh]" />;
  }

  if (!authed) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-md flex-col justify-center px-6 py-20">
        <span className="font-mono text-[12px] uppercase tracking-widest text-signal">
          Console access
        </span>
        <h1 className="mt-5 text-3xl font-semibold tracking-tight text-ink sm:text-4xl">
          Open your dashboard.
        </h1>
        <p className="mt-4 text-base leading-relaxed text-muted">
          Your console key is printed in your terminal when you install
          stackcircuit365 from npm. Paste it here to open the dashboard for your
          app.
        </p>
        <form onSubmit={submit} className="mt-6">
          <input
            value={keyInput}
            onChange={(e) => setKeyInput(e.target.value)}
            placeholder="Console key"
            aria-label="Console key"
            className="w-full border border-line bg-card px-4 py-3 font-mono text-[14px] text-ink outline-none"
          />
          <button
            type="submit"
            className="mt-3 w-full bg-ink px-5 py-3 font-mono text-[13px] uppercase tracking-widest text-paper"
          >
            Open dashboard
          </button>
        </form>
        {error ? (
          <p className="mt-3 font-mono text-[12px] text-alert">{error}</p>
        ) : null}
        <p className="mt-6 font-mono text-[11px] text-muted">
          Testing key: 12345678
        </p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <div className="mb-6 flex flex-col gap-2 border border-line bg-card px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
        <span className="font-mono text-[11px] text-muted">
          Preview dashboard. Live data connects when you run the module with your
          key.
        </span>
        <span className="font-mono text-[11px] uppercase tracking-widest text-signal">
          Auto-refreshes every 5s
        </span>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-[210px_1fr]">
        {/* Sidebar */}
        <aside className="border border-line bg-card md:self-start">
          <div className="border-b border-line2 px-4 py-4">
            <p className="font-mono text-[11px] uppercase tracking-widest text-muted">
              Console
            </p>
            <p className="mt-1 font-mono text-[13px] text-ink">app.example.dev</p>
          </div>
          <nav className="flex flex-row flex-wrap gap-px bg-line2 md:flex-col">
            {NAV.map((item) => {
              const active = item === tab;
              return (
                <button
                  key={item}
                  type="button"
                  onClick={() => setTab(item)}
                  className={`flex-1 px-4 py-3 text-left font-mono text-[13px] uppercase tracking-widest md:flex-none ${
                    active ? "bg-ink text-paper" : "bg-card text-muted"
                  }`}
                >
                  {item}
                </button>
              );
            })}
          </nav>
          <div className="flex items-center justify-between border-t border-line2 px-4 py-3">
            <span className="font-mono text-[11px] text-muted">···· 5678</span>
            <button
              type="button"
              onClick={signOut}
              className="font-mono text-[11px] uppercase tracking-widest text-ink underline"
            >
              Sign out
            </button>
          </div>
        </aside>

        {/* Main */}
        <div>
          <div className="mb-5 flex items-center justify-between">
            <h2 className="font-mono text-[13px] uppercase tracking-widest text-ink">
              {tab}
            </h2>
            <div className="flex items-center gap-2">
              <span
                className="h-2.5 w-2.5"
                style={{ backgroundColor: SEVERITY[severity].color }}
              />
              <span className="font-mono text-[11px] uppercase tracking-widest text-muted">
                {SEVERITY[severity].label}
              </span>
            </div>
          </div>
          <TabContent tab={tab} />
        </div>
      </div>

      <p className="mt-8 font-mono text-[11px] text-muted">
        Not your app?{" "}
        <Link href="/" className="text-ink underline">
          Back to the site.
        </Link>
      </p>
    </div>
  );
}
