"use client";

import { useEffect, useRef, useState } from "react";

interface CountUpProps {
  /** The text to display, e.g. "Under 90s" or "Zero" */
  text: string;
  /** Duration of the count-up animation in ms */
  duration?: number;
  /** Delay before starting */
  delay?: number;
  /** Color variant */
  variant?: "light" | "dark";
  className?: string;
}

/**
 * Extracts a numeric portion from text and animates it counting up.
 * Non-numeric text (e.g. "Zero", "Under 3 min") gets a typewriter reveal.
 */
export default function CountUp({
  text,
  duration = 1200,
  delay = 0,
  variant = "light",
  className = ""
}: CountUpProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(false);
  const [display, setDisplay] = useState(text);

  // Extract number from strings like "Under 90s", "Under 3 min"
  const match = text.match(/(\d+)/);
  const hasNumber = !!match;
  const targetNum = hasNumber ? parseInt(match![1], 10) : 0;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setStarted(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!started) return;

    if (!hasNumber) {
      // Typewriter effect for non-numeric text like "Zero"
      let i = 0;
      const timer = setTimeout(() => {
        const interval = setInterval(() => {
          i++;
          setDisplay(text.slice(0, i));
          if (i >= text.length) clearInterval(interval);
        }, 60);
        return () => clearInterval(interval);
      }, delay);
      return () => clearTimeout(timer);
    }

    // Count up animation for numeric text
    const startTime = performance.now() + delay;
    let raf: number;

    function tick(now: number) {
      const elapsed = now - startTime;
      if (elapsed < 0) {
        raf = requestAnimationFrame(tick);
        return;
      }
      const progress = Math.min(elapsed / duration, 1);
      // Ease out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(eased * targetNum);
      setDisplay(text.replace(/\d+/, String(current)));
      if (progress < 1) {
        raf = requestAnimationFrame(tick);
      }
    }

    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [started, hasNumber, targetNum, text, duration, delay]);

  const textColor = variant === "dark" ? "text-paper" : "text-ink";

  return (
    <div ref={ref} className={className}>
      <span className={`font-mono text-4xl font-semibold ${textColor} tabular-nums sm:text-5xl`}>
        {started ? display : " "}
      </span>
    </div>
  );
}
