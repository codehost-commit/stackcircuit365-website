"use client";

import { useEffect, useRef, useState } from "react";

export default function VideoPlayer() {
  const ref = useRef<HTMLVideoElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const [playing, setPlaying] = useState(false);

  /* Auto-play when scrolled into view */
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && ref.current) {
          ref.current.play().catch(() => {});
        }
      },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  function handleClick() {
    const v = ref.current;
    if (!v) return;
    if (v.paused) {
      v.play().catch(() => {});
    } else {
      v.pause();
    }
  }

  return (
    <div
      ref={wrapRef}
      className="relative border border-white/10 bg-[#101216]"
    >
      {/* Top accent bar */}
      <div className="absolute inset-x-0 top-0 z-10 h-[3px] bg-signal" />

      <video
        ref={ref}
        src="/video/demo.mp4"
        poster="/video/poster.jpg"
        muted
        loop
        playsInline
        preload="metadata"
        onClick={handleClick}
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        className="block w-full cursor-pointer"
      />

      {/* Play overlay when paused */}
      {!playing && (
        <button
          type="button"
          onClick={handleClick}
          aria-label="Play video"
          className="absolute inset-0 z-20 flex items-center justify-center bg-black/30"
        >
          <div className="flex h-20 w-20 items-center justify-center border-2 border-paper bg-ink/80">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              className="ml-1 h-8 w-8"
              aria-hidden="true"
            >
              <path d="M8 5v14l11-7L8 5z" fill="#f7f7f4" />
            </svg>
          </div>
        </button>
      )}
    </div>
  );
}
