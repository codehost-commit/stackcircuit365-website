"use client";

import { useEffect, useState, useRef } from "react";

/**
 * DashboardLive: a self-contained, auto-simulating dashboard
 * designed for recording a demo video. Cycles through severity
 * states, ticks stats, scrolls alerts, and animates deploys.
 */

const SEVERITY = {
  ok: { color: "#0f7a3d", label: "Operational", note: "All checks passing" },
  minor: { color: "#9a7d0a", label: "Minor", note: "Elevated errors" },
  major: { color: "#b5651d", label: "Major", note: "Degraded service" },
  critical: { color: "#b42318", label: "Critical", note: "Outage in progress" }
} as const;

type Sev = keyof typeof SEVERITY;
const SEV_ORDER: Sev[] = ["ok", "minor", "major", "critical"];

// Scenario: ok -> minor -> major -> critical -> ok (recovered)
const scenario: { sev: Sev; latency: number; errorRate: string; checks: string; alert: string }[] = [
  { sev: "ok", latency: 210, errorRate: "0.02%", checks: "12 of 12 passing", alert: "All systems operational" },
  { sev: "ok", latency: 215, errorRate: "0.03%", checks: "12 of 12 passing", alert: "Deploy dpl_7c33a promoted" },
  { sev: "minor", latency: 890, errorRate: "2.1%", checks: "9 of 12 passing", alert: "Elevated error rate detected" },
  { sev: "major", latency: 3200, errorRate: "18%", checks: "4 of 12 passing", alert: "Health checks failing, confidence 0.87" },
  { sev: "critical", latency: 8100, errorRate: "64%", checks: "1 of 12 passing", alert: "Incident opened, confidence 0.93" },
  { sev: "critical", latency: 9500, errorRate: "78%", checks: "0 of 12 passing", alert: "Rollback recommended to dpl_6b0f9" },
  { sev: "major", latency: 1800, errorRate: "8%", checks: "7 of 12 passing", alert: "Rollback in progress..." },
  { sev: "minor", latency: 450, errorRate: "1.2%", checks: "10 of 12 passing", alert: "Recovery in progress, verifying..." },
  { sev: "ok", latency: 205, errorRate: "0.02%", checks: "12 of 12 passing", alert: "Recovery verified. Incident closed." },
];

function formatTime(base: Date, offsetSec: number) {
  const d = new Date(base.getTime() + offsetSec * 1000);
  return d.toLocaleTimeString("en-US", { hour12: false, hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export default function DashboardLive() {
  const [frame, setFrame] = useState(0);
  const [pulseOn, setPulseOn] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const baseTime = useRef(new Date());

  const sc = scenario[frame % scenario.length];
  const s = SEVERITY[sc.sev];

  // Observe visibility
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => setIsVisible(entry.isIntersecting),
      { threshold: 0.15 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  // Auto-advance frames
  useEffect(() => {
    if (!isVisible) return;
    const t = setInterval(() => {
      setFrame((f) => {
        const next = f + 1;
        if (next >= scenario.length) {
          baseTime.current = new Date();
          return 0;
        }
        return next;
      });
    }, 2000);
    return () => clearInterval(t);
  }, [isVisible]);

  // Pulse effect on severity box
  useEffect(() => {
    if (sc.sev === "ok") {
      setPulseOn(false);
      return;
    }
    const interval = setInterval(() => setPulseOn((p) => !p), 1200);
    return () => clearInterval(interval);
  }, [sc.sev]);

  // Build alerts log from scenario steps up to current frame
  const alerts = scenario.slice(0, frame + 1).map((step, i) => ({
    time: formatTime(baseTime.current, i * 2),
    text: step.alert,
    sev: step.sev
  })).reverse();

  return (
    <div ref={containerRef} className="border border-line bg-card">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-line2 px-4 py-2.5">
        <span className="font-mono text-[11px] uppercase tracking-widest text-muted">
          Live simulation
        </span>
        <div className="flex items-center gap-2">
          <span
            className="h-2 w-2 transition-colors duration-500"
            style={{ backgroundColor: s.color }}
          />
          <span
            className="font-mono text-[11px] uppercase tracking-widest transition-colors duration-500"
            style={{ color: s.color }}
          >
            {s.label}
          </span>
        </div>
      </div>

      {/* Severity color bar */}
      <div
        className="h-1.5 transition-all duration-700 ease-in-out"
        style={{ backgroundColor: s.color }}
      />

      <div className="grid grid-cols-1 gap-px bg-line2 lg:grid-cols-[1fr_1.4fr]">
        {/* Left: Severity box */}
        <div className="bg-card p-5">
          <div
            className="border transition-all duration-700"
            style={{
              backgroundColor: s.color,
              borderColor: pulseOn ? "rgba(255,255,255,0.15)" : "rgba(255,255,255,0.05)"
            }}
          >
            <div className="p-6">
              <span className="font-mono text-[11px] uppercase tracking-widest text-paper/80">
                System status
              </span>
              <div className="mt-2 text-4xl font-semibold text-paper transition-all duration-500">
                {s.label}
              </div>
              <div className="mt-2 font-mono text-[13px] text-paper/90">
                {s.note}
              </div>
            </div>
          </div>

          {/* Legend */}
          <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1">
            {SEV_ORDER.map((k) => (
              <span
                key={k}
                className="flex items-center gap-1.5 font-mono text-[10px] text-muted"
              >
                <span
                  className="h-2 w-2"
                  style={{ backgroundColor: SEVERITY[k].color }}
                />
                {SEVERITY[k].label}
              </span>
            ))}
          </div>

          {/* Live stats */}
          <div className="mt-5 border border-line divide-y divide-line2">
            {[
              ["Latency p95", `${sc.latency}ms`],
              ["Error rate", sc.errorRate],
              ["Checks", sc.checks],
            ].map(([label, val]) => (
              <div key={label} className="flex items-center justify-between px-4 py-2.5 font-mono text-[13px]">
                <span className="text-muted">{label}</span>
                <span className="text-ink font-medium tabular-nums transition-all duration-300">{val}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Alerts feed */}
        <div className="bg-card">
          <div className="border-b border-line2 px-4 py-2.5">
            <span className="font-mono text-[11px] uppercase tracking-widest text-muted">
              Event log
            </span>
          </div>
          <div className="max-h-[320px] overflow-y-auto">
            {alerts.map((a, i) => (
              <div
                key={`${a.time}-${i}`}
                className="flex items-start gap-3 border-b border-line2 px-4 py-3 font-mono text-[13px]"
                style={{
                  opacity: i === 0 ? 1 : 0.7 + 0.3 * (1 - i / alerts.length),
                  animation: i === 0 ? "sc-event-in 0.3s ease" : "none"
                }}
              >
                <span className="text-muted tabular-nums shrink-0">{a.time}</span>
                <span
                  className="h-2 w-2 shrink-0 mt-0.5"
                  style={{ backgroundColor: SEVERITY[a.sev].color }}
                />
                <span className="text-ink">{a.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
