"use client";

import { useEffect, useRef, useState } from "react";

interface TerminalTypeProps {
  /** Lines to type out. Each line object has text and optional color. */
  lines: { text: string; color?: string }[];
  /** Delay between characters in ms */
  charDelay?: number;
  /** Delay between lines in ms */
  lineDelay?: number;
  /** Initial delay before typing starts */
  startDelay?: number;
  className?: string;
}

export default function TerminalType({
  lines,
  charDelay = 25,
  lineDelay = 300,
  startDelay = 0,
  className = ""
}: TerminalTypeProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [started, setStarted] = useState(false);
  const [visibleLines, setVisibleLines] = useState<
    { text: string; color?: string; done: boolean }[]
  >([]);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setStarted(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!started) return;

    let cancelled = false;
    const output: { text: string; color?: string; done: boolean }[] = [];

    async function run() {
      await wait(startDelay);
      if (cancelled) return;

      for (let li = 0; li < lines.length; li++) {
        if (cancelled) return;
        const line = lines[li];
        output.push({ text: "", color: line.color, done: false });

        for (let ci = 0; ci <= line.text.length; ci++) {
          if (cancelled) return;
          output[li] = {
            text: line.text.slice(0, ci),
            color: line.color,
            done: ci === line.text.length
          };
          setVisibleLines([...output]);
          if (ci < line.text.length) await wait(charDelay);
        }

        if (li < lines.length - 1) await wait(lineDelay);
      }
    }

    run();
    return () => {
      cancelled = true;
    };
  }, [started, lines, charDelay, lineDelay, startDelay]);

  return (
    <div ref={ref} className={className}>
      {visibleLines.map((line, i) => (
        <div
          key={i}
          className={i === 0 ? "" : "mt-1"}
          style={line.color ? { color: line.color } : undefined}
        >
          {line.text}
          {!line.done && (
            <span className="sc-caret inline-block w-[7px] h-[14px] bg-current ml-px align-middle" />
          )}
        </div>
      ))}
      {!started && (
        <div>
          <span className="sc-caret inline-block w-[7px] h-[14px] bg-ink ml-px align-middle" />
        </div>
      )}
    </div>
  );
}

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
