import Link from "next/link";

function DevMock() {
  return (
    <div className="border border-white/15 bg-[#101216] p-5 font-mono text-[13px] leading-relaxed text-paper/80 shadow-[0_-8px_30px_rgba(0,0,0,0.35)]">
      <div className="text-paper/45">$ stackcircuit watch</div>
      <div>
        <span className="text-paper/45">[14:02:11]</span> deploy dpl_7c33a
      </div>
      <div>
        <span style={{ color: "#f2857a" }}>[14:03:47]</span> health 500 x4 p95 3.2s
      </div>
      <div>
        <span style={{ color: "#5bd08a" }}>[14:04:05]</span> incident conf 0.93
      </div>
      <div>
        <span className="text-paper/45">[14:05:38]</span> rollback verified
      </div>
    </div>
  );
}

function BeginnerMock() {
  return (
    <div className="border border-line bg-paper p-5 shadow-[0_-8px_30px_rgba(0,0,0,0.12)]">
      <div className="flex items-center justify-between">
        <span className="font-mono text-[13px] text-muted">Your site</span>
        <span className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 bg-signal" />
          <span className="font-mono text-[13px] text-signal">Healthy</span>
        </span>
      </div>
      <div className="mt-3 font-mono text-[13px] text-muted">
        Checked 20 seconds ago
      </div>
      <div className="mt-1 font-mono text-[13px] text-muted">
        Last good version is saved
      </div>
    </div>
  );
}

export default function AudienceSplit() {
  return (
    <div className="audience">
      <Link href="/for-developers" className="audience-panel audience-dark">
        <div className="audience-body">
          <span className="font-mono text-[12px] uppercase tracking-widest text-paper/50">
            For developers
          </span>
          <h3 className="mt-5 text-4xl font-semibold text-paper sm:text-5xl">
            For Developers
          </h3>
          <p className="mt-5 max-w-sm text-lg leading-relaxed text-paper/70">
            You know a deploy from a rollback. See what runs under the hood, from
            the webhook to the verified recovery.
          </p>
          <span className="mt-8 inline-block border border-paper/40 px-5 py-3 font-mono text-[13px] uppercase tracking-widest text-paper">
            See the developer walkthrough
          </span>
        </div>
        <div className="audience-peek">
          <DevMock />
        </div>
      </Link>

      <Link href="/for-beginners" className="audience-panel audience-light">
        <div className="audience-body">
          <span className="font-mono text-[12px] uppercase tracking-widest text-signal">
            For beginners
          </span>
          <h3 className="mt-5 text-4xl font-semibold text-ink sm:text-5xl">
            For Beginners
          </h3>
          <p className="mt-5 max-w-sm text-lg leading-relaxed text-muted">
            New to shipping to production? Here is the plain version of what
            StackCircuit365 does for you.
          </p>
          <span className="mt-8 inline-block border border-ink px-5 py-3 font-mono text-[13px] uppercase tracking-widest text-ink">
            See the simple version
          </span>
        </div>
        <div className="audience-peek">
          <BeginnerMock />
        </div>
      </Link>
    </div>
  );
}
