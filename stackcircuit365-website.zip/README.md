# StackCircuit365 Website

Marketing site for StackCircuit365, hosted at stackcircuit.dev.
Built with Next.js (App Router), TypeScript, and Tailwind CSS.

## Develop

    npm install
    npm run dev

Open http://localhost:3000

## Pages

- `/`       Home (hero, countdown, how it works, recovery modes, incident demo, scope, safety, early access)
- `/about`  About the product and the two founders
- `/legal`  Terms of Service, Privacy Policy, Attributions (one page, anchored)

## Founder photos

Drop the two founder images into `public/founders/`:

- `public/founders/founder-1.jpeg`  ->  Rahul Awasthi (Lead Developer and Architect)
- `public/founders/founder-2.jpeg`  ->  Pritam Avuthu (Lead Product Designer)

Portrait orientation looks best (roughly 4:5, for example 520 x 650). Placeholder
files are committed so the layout renders; replace them with the real photos.

## Deploy

Deploys cleanly to Vercel. Set the domain to stackcircuit.dev.
