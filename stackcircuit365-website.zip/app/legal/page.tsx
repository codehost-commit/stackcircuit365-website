import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Legal",
  description:
    "Terms of Service, Privacy Policy, and Attributions for StackCircuit365."
};

const nav = [
  { href: "#terms", label: "Terms of Service" },
  { href: "#privacy", label: "Privacy Policy" },
  { href: "#attributions", label: "Attributions" }
];

function Clause({
  n,
  title,
  children
}: {
  n: string;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="border-t border-line2 py-7">
      <div className="flex items-baseline gap-3">
        <span className="font-mono text-[12px] text-signal">{n}</span>
        <h3 className="text-lg font-medium text-ink">{title}</h3>
      </div>
      <div className="mt-3 max-w-2xl space-y-3 text-[15px] leading-relaxed text-muted">
        {children}
      </div>
    </div>
  );
}

export default function Legal() {
  return (
    <div>
      <section className="border-b border-line">
        <div className="mx-auto max-w-6xl px-6 py-16">
          <span className="font-mono text-[12px] uppercase tracking-widest text-signal">
            Legal
          </span>
          <h1 className="mt-6 text-4xl font-semibold tracking-tight text-ink sm:text-5xl">
            Terms, privacy, and attributions.
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted">
            Effective September 2, 2026. StackCircuit365 is prerelease software.
            These terms and this policy cover the current 0.5.0 prerelease and
            will be updated as the product reaches its public launch. Questions
            can go to hello@stackcircuit.dev.
          </p>
        </div>
      </section>

      <div className="mx-auto grid max-w-6xl grid-cols-1 gap-12 px-6 py-16 lg:grid-cols-[16rem_1fr]">
        {/* Side nav */}
        <aside className="lg:sticky lg:top-24 lg:self-start">
          <p className="font-mono text-[11px] uppercase tracking-widest text-muted">
            On this page
          </p>
          <nav className="mt-4 flex flex-col gap-3 border-l border-line pl-4">
            {nav.map((n) => (
              <a
                key={n.href}
                href={n.href}
                className="font-mono text-[13px] text-ink"
              >
                {n.label}
              </a>
            ))}
          </nav>
        </aside>

        {/* Content */}
        <div className="max-w-3xl">
          {/* TERMS */}
          <section id="terms" className="scroll-mt-24">
            <h2 className="text-2xl font-semibold tracking-tight text-ink">
              Terms of Service
            </h2>
            <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-muted">
              By installing the StackCircuit365 GitHub App, connecting a Vercel
              project, or using the service in any form, you agree to the terms
              below.
            </p>

            <Clause n="1.0" title="The service">
              <p>
                StackCircuit365 monitors deployments from GitHub to Vercel,
                detects release regressions in production, recommends or performs
                rollbacks under rules you configure, and produces incident
                reports. During the prerelease it is offered for evaluation and
                may change without notice. StackCircuit365 is free to use, with no
                paid tiers.
              </p>
            </Clause>

            <Clause n="2.0" title="Your responsibilities">
              <p>
                You are responsible for the code you deploy, for the recovery
                mode you select, and for reviewing any rollback recommendation
                before you approve it. Auto-Recover is off by default and takes
                effect only after you enable it and accept the risks described in
                the dashboard.
              </p>
            </Clause>

            <Clause n="3.0" title="Access and permissions">
              <p>
                The GitHub App requests the minimum permissions needed to do its
                job. It starts with read access to repository metadata and
                contents. Any write permission, such as creating issues or draft
                pull requests, is opt in and can be revoked at any time from
                GitHub.
              </p>
            </Clause>

            <Clause n="4.0" title="Automated actions">
              <p>
                A deterministic policy engine governs every rollback and every
                write. The service will not automatically touch database
                migrations, authentication, authorization, billing, secrets,
                environment variables, or any change it cannot verify as safe. In
                those cases it stops and alerts you.
              </p>
            </Clause>

            <Clause n="5.0" title="Prerelease software, provided as is">
              <p>
                The prerelease is provided without warranties of any kind. We do
                our best to make recovery safe and correct, but you should not
                rely on it as the only safeguard for a production system.
                StackCircuit365 is not liable for indirect or consequential
                damages arising from use of the prerelease.
              </p>
            </Clause>

            <Clause n="6.0" title="Free forever, with fair use">
              <p>
                StackCircuit365 is free to use and has no paid tiers. Core
                release monitoring, incident reports, rollback recommendations,
                and policy-controlled recovery stay free. Reasonable fair-use
                limits keep it sustainable, such as one repository, one Vercel
                project, one production URL, standard health checks, a limited
                incident history, and a capped number of repair attempts. These
                limits may be adjusted over time, but the product stays free.
              </p>
            </Clause>

            <Clause n="7.0" title="Changes and termination">
              <p>
                You can disconnect StackCircuit365 from GitHub and Vercel at any
                time. We may update these terms as the product matures and will
                post the effective date at the top of this page.
              </p>
            </Clause>
          </section>

          {/* PRIVACY */}
          <section id="privacy" className="mt-20 scroll-mt-24">
            <h2 className="text-2xl font-semibold tracking-tight text-ink">
              Privacy Policy
            </h2>
            <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-muted">
              We collect the minimum needed to detect regressions and recover a
              release. We do not sell your data.
            </p>

            <Clause n="1.0" title="What we collect">
              <p>
                We store deployment events from Vercel, commit metadata from
                GitHub, health-check results from your production URL, and the
                email address you choose for alerts. We do not clone your
                repository or read source code beyond what is needed to identify
                changed files during an incident.
              </p>
            </Clause>

            <Clause n="2.0" title="How we use it">
              <p>
                This data is used to run health checks, correlate a failure with
                a deployment, build an incident report, and send alerts. Webhook
                events are signature verified and stored for audit so that every
                automated action can be traced.
              </p>
            </Clause>

            <Clause n="3.0" title="Third parties">
              <p>
                StackCircuit365 works with the services you connect, including
                GitHub and Vercel, and uses infrastructure providers for
                hosting, email delivery, and error tracking. Each processes data
                only to provide its part of the service.
              </p>
            </Clause>

            <Clause n="4.0" title="Retention and control">
              <p>
                Incident history is kept for a limited period on the free tier.
                When you disconnect the GitHub App or the Vercel integration, we
                stop collecting new data for that project. You can request
                deletion of your account data by writing to
                hello@stackcircuit.dev.
              </p>
            </Clause>

            <Clause n="5.0" title="Security">
              <p>
                Access to production actions is gated by the policy engine and by
                your recovery mode. Secrets and credentials are never required
                for the read-only monitoring that the prerelease is built around.
              </p>
            </Clause>
          </section>

          {/* ATTRIBUTIONS */}
          <section id="attributions" className="mt-20 scroll-mt-24">
            <h2 className="text-2xl font-semibold tracking-tight text-ink">
              Attributions
            </h2>
            <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-muted">
              StackCircuit365 is designed and built by its two co-founders.
            </p>

            <div className="mt-6 border border-line">
              <div className="grid grid-cols-1 sm:grid-cols-2">
                <div className="border-b border-line2 p-6 sm:border-b-0 sm:border-r">
                  <p className="text-lg font-medium text-ink">Rahul Awasthi</p>
                  <p className="mt-1 font-mono text-[12px] uppercase tracking-widest text-muted">
                    Lead Developer and Architect
                  </p>
                  <p className="mt-3 text-sm leading-relaxed text-muted">
                    Detection and recovery engine, policy engine, and platform
                    architecture.
                  </p>
                </div>
                <div className="p-6">
                  <p className="text-lg font-medium text-ink">Pritam Avuthu</p>
                  <p className="mt-1 font-mono text-[12px] uppercase tracking-widest text-muted">
                    Lead Product Designer
                  </p>
                  <p className="mt-3 text-sm leading-relaxed text-muted">
                    Product design, incident reporting experience, and the
                    StackCircuit365 brand.
                  </p>
                </div>
              </div>
            </div>

            <p className="mt-6 max-w-2xl text-sm leading-relaxed text-muted">
              StackCircuit365 is built with Next.js, TypeScript, and Tailwind
              CSS. Product and company names referenced on this site, including
              GitHub and Vercel, are trademarks of their respective owners and
              are used here for identification only.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
