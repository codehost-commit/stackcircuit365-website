import type { Metadata } from "next";
import Link from "next/link";
import DevSteps from "./DevSteps";

export const metadata: Metadata = {
  title: "For Developers",
  description:
    "How StackCircuit365 works under the hood: from the Vercel webhook to a verified rollback, with the policy engine in control."
};

export default function ForDevelopers() {
  return (
    <div>
      {/* Dark hero */}
      <section className="bg-ink">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <div className="mx-auto max-w-3xl">
            <span className="font-mono text-[13px] uppercase tracking-widest text-paper/50">
              For developers
            </span>
            <h1 className="mt-6 text-4xl font-semibold leading-[1.08] tracking-tight text-paper sm:text-5xl lg:text-6xl">
              Under the hood.
            </h1>
            <p className="mt-8 max-w-2xl text-xl leading-relaxed text-paper/70">
              From the Vercel webhook to a verified rollback, here is the exact path
              a release runs through. A deterministic policy engine controls every
              write. The AI only reads evidence and drafts the report.
            </p>
          </div>
          <div className="mx-auto mt-14 max-w-3xl">
            <DevSteps />
          </div>
        </div>
      </section>

      {/* Steps */}
      <section className="border-b border-line">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <div className="border border-line bg-paper">
            {[
              {
                n: "01",
                title: "Ingest the deploy event",
                body: "Vercel fires deployment.succeeded. We verify the signature, persist the event, and resolve it to a GitHub SHA.",
                code: ["POST /webhooks/vercel  200", "dpl_7c33a  ->  e9f14a2"]
              },
              {
                n: "02",
                title: "Tighten the health window",
                body: "For ten to fifteen minutes after promotion, polls drop to every few seconds against your URL and optional /health.",
                code: ["GET /api/health 200 210ms", "GET /api/health 500 3.2s  x4"]
              },
              {
                n: "03",
                title: "Correlate and score",
                body: "Failure onset is diffed against deploy time and checked against dependency status before any verdict is reached.",
                code: ["onset delta 1m54s", "deps ok   confidence 0.93"]
              },
              {
                n: "04",
                title: "Recover to known-good",
                body: "The last verified deployment is the target. Your policy decides recommend or execute, then we re-poll to confirm.",
                code: ["rollback -> dpl_6b0f9", "verify 10/10  70s"]
              },
              {
                n: "05",
                title: "Emit a replayable record",
                body: "A signed incident timeline with the commit, deploy, checks, cause, action, and recovery, ready to audit.",
                code: ["incident inc_20260904", "status closed  signed"]
              }
            ].map((s) => (
              <div
                key={s.n}
                className="grid grid-cols-1 gap-6 border-b border-line2 p-8 last:border-b-0 md:grid-cols-[3.5rem_1fr_1.05fr] md:items-start md:gap-8 md:p-10"
              >
                <span className="font-mono text-2xl font-semibold text-ink">{s.n}</span>
                <div>
                  <h3 className="text-xl font-medium text-ink">{s.title}</h3>
                  <p className="mt-3 max-w-md text-base leading-relaxed text-muted">
                    {s.body}
                  </p>
                </div>
                <div className="relative overflow-x-auto border border-line bg-card p-6 font-mono text-[13px] leading-relaxed text-ink">
                  <div className="absolute inset-y-0 left-0 w-[2px] bg-signal" />
                  {s.code.map((line, i) => (
                    <div key={i} className={i === 0 ? "" : "mt-1 text-muted"}>
                      {line}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-14 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-lg text-muted">
              New to shipping to production?{" "}
              <Link href="/for-beginners" className="font-mono text-ink underline">
                See the simple version.
              </Link>
            </p>
            <a
              href="https://www.npmjs.com/package/stackcircuit365"
              target="_blank"
              rel="noreferrer"
              className="w-fit bg-ink px-6 py-3.5 font-mono text-[14px] uppercase tracking-widest text-paper"
            >
              Install from npm
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
