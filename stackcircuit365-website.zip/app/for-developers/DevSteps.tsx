"use client";

import TerminalType from "@/components/TerminalType";

const heroLines = [
  { text: "$ npm i -g stackcircuit365" },
  {
    text: "$ stackcircuit watch --repo you/app --prod https://app.example.dev"
  },
  { text: "baseline healthy // known-good locked: dpl_9f21c", color: "#5bd08a" }
];

export default function DevSteps() {
  return (
    <div className="relative mt-10 border border-white/15 bg-[#101216] p-6 font-mono text-[13px] leading-relaxed text-paper/80 sm:p-8 sm:text-[14px]">
      {/* Signal-green left accent */}
      <div className="absolute inset-y-0 left-0 w-[3px] bg-signal" />
      <TerminalType
        lines={heroLines}
        charDelay={28}
        lineDelay={400}
        startDelay={300}
      />
    </div>
  );
}
