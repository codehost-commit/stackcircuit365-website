import type { Metadata } from "next";
import DemoClient from "./DemoClient";

export const metadata: Metadata = {
  title: "Demo",
  description:
    "A cinematic walkthrough of StackCircuit365 for recording a motion demo video."
};

export default function DemoPage() {
  return <DemoClient />;
}
