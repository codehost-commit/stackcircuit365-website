"use client";

import Countdown from "@/components/Countdown";
import IncidentTimeline from "@/components/IncidentTimeline";
import DashboardLive from "@/components/DashboardLive";
import TerminalType from "@/components/TerminalType";
import CountUp from "@/components/CountUp";
import ScrollReveal from "@/components/ScrollReveal";
import VideoPlayer from "@/components/VideoPlayer";
import Logo from "@/components/Logo";

const terminalLines = [
  { text: "$ npm i -g stackcircuit365" },
  { text: "$ stackcircuit watch --repo you/app --prod https://app.example.dev" },
  { text: "baseline healthy // known-good locked: dpl_9f21c", color: "#5bd08a" }
];

const stats: [string, string][] = [
  ["Under 90s", "to detect a hard outage"],
  ["Under 3 min", "to verified recovery on clear cases"],
  ["Zero", "unsafe automated actions, by design"]
];

export default function DemoClient() {
  return (
    <div>
      {/* S1: Hero with logo and countdown */}
      <section className="flex min-h-[100svh] items-center border-b border-line">
        <div className="mx-auto w-full max-w-[1200px] px-6 py-32 lg:py-40">
          <div className="mx-auto max-w-4xl text-center">
            <ScrollReveal>
              <Logo />
            </ScrollReveal>

            <ScrollReveal delay={200}>
              <h1 className="mt-12 text-[clamp(2.5rem,6vw,5.5rem)] font-semibold leading-[1.04] tracking-tight text-ink">
                Every release has a<br className="hidden sm:block" /> safety circuit.
              </h1>
            </ScrollReveal>

            <ScrollReveal delay={400}>
              <p className="mx-auto mt-10 max-w-2xl text-xl leading-relaxed text-muted sm:text-2xl sm:leading-relaxed">
                StackCircuit365 watches your GitHub to Vercel deployments. When a
                release breaks production, it works out which deploy caused it and
                brings back your last verified healthy version. Free forever.
              </p>
            </ScrollReveal>

            <ScrollReveal delay={600}>
              <div className="mx-auto mt-14 max-w-lg">
                <Countdown />
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* S1.5: Video showcase */}
      <section className="bg-ink">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <ScrollReveal>
            <div className="mx-auto max-w-3xl text-center">
              <span className="font-mono text-[13px] uppercase tracking-widest text-signal">
                Product walkthrough
              </span>
              <h2 className="mt-6 text-4xl font-semibold tracking-tight text-paper sm:text-5xl lg:text-6xl">
                See the full cycle in action.
              </h2>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={200}>
            <div className="mt-16">
              <VideoPlayer />
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* S2: Terminal install sequence */}
      <section className="bg-ink border-t border-white/10">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <div className="grid grid-cols-1 gap-16 lg:grid-cols-[1fr_1.2fr] lg:items-center">
            <ScrollReveal>
              <span className="font-mono text-[13px] uppercase tracking-widest text-signal">
                Get started
              </span>
              <h2 className="mt-6 text-4xl font-semibold tracking-tight text-paper sm:text-5xl">
                One command to protect your app.
              </h2>
              <div className="mt-10 grid grid-cols-1 gap-px border border-white/10 bg-white/10">
                {[
                  ["Webhook verified", "Vercel deployment events are signature-checked and stored."],
                  ["Health window active", "Rapid polling begins on your production URL and /api/health."],
                  ["Known-good locked", "The last verified deploy is saved as the rollback target."]
                ].map(([title, desc]) => (
                  <div key={title} className="bg-ink p-6">
                    <p className="font-mono text-[12px] uppercase tracking-widest text-signal">{title}</p>
                    <p className="mt-2 text-base leading-relaxed text-paper/60">{desc}</p>
                  </div>
                ))}
              </div>
            </ScrollReveal>

            <ScrollReveal delay={300}>
              <div className="relative border border-white/15 bg-[#101216] p-8 font-mono text-[15px] leading-relaxed text-paper/80 sm:p-10 sm:text-[16px]">
                <div className="absolute inset-y-0 left-0 w-[3px] bg-signal" />
                <TerminalType
                  lines={terminalLines}
                  charDelay={30}
                  lineDelay={500}
                  startDelay={400}
                />
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* S3: Live incident timeline (auto-play) */}
      <section className="border-b border-line">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <div className="grid grid-cols-1 gap-16 lg:grid-cols-[1fr_1.2fr] lg:items-start">
            <ScrollReveal>
              <span className="font-mono text-[13px] uppercase tracking-widest text-signal">
                Incident replay
              </span>
              <h2 className="mt-6 text-4xl font-semibold tracking-tight text-ink sm:text-5xl">
                Watch a regression get contained.
              </h2>
              <p className="mt-6 max-w-2xl text-xl leading-relaxed text-muted">
                A bad deploy hits production. StackCircuit365 detects it in seconds,
                correlates it to the commit, and recovers your app.
              </p>
            </ScrollReveal>

            <ScrollReveal delay={300}>
              <IncidentTimeline autoPlay intervalMs={2500} />
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* S4: Dashboard live simulation */}
      <section className="border-b border-line bg-card">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <ScrollReveal>
            <div className="mx-auto max-w-3xl text-center">
              <span className="font-mono text-[13px] uppercase tracking-widest text-signal">
                Dashboard
              </span>
              <h2 className="mt-6 text-4xl font-semibold tracking-tight text-ink sm:text-5xl lg:text-6xl">
                Your production status, live.
              </h2>
              <p className="mx-auto mt-6 max-w-2xl text-xl leading-relaxed text-muted">
                Every deploy, every health check, every recovery decision in one
                console, updating in real time.
              </p>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={300}>
            <div className="mt-16">
              <DashboardLive />
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* S5: Safety stats with count-up */}
      <section className="border-b border-line bg-ink">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <div className="grid grid-cols-1 gap-16 lg:grid-cols-[1fr_1fr]">
            <ScrollReveal>
              <span className="font-mono text-[13px] uppercase tracking-widest text-signal">
                Safety first
              </span>
              <h2 className="mt-6 text-4xl font-semibold tracking-tight text-paper sm:text-5xl">
                The AI never decides to change production.
              </h2>
              <p className="mt-6 text-xl leading-relaxed text-paper/70">
                A deterministic policy engine controls every rollback and every
                write. The AI reads evidence, connects a failure to a commit, and
                drafts the report a human reviews.
              </p>
            </ScrollReveal>

            <div className="lg:pt-16">
              <div className="border border-white/10">
                {stats.map(([stat, label], i) => (
                  <div
                    key={stat}
                    className="border-b border-white/10 px-8 py-10 last:border-b-0"
                  >
                    <CountUp text={stat} delay={i * 300} duration={1400} variant="dark" />
                    <div className="mt-3 text-lg text-paper/60">{label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* S6: Recovery modes */}
      <section className="border-b border-line bg-ink border-t border-white/10">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <ScrollReveal>
            <div className="mx-auto max-w-3xl text-center">
              <span className="font-mono text-[13px] uppercase tracking-widest text-signal">
                Recovery modes
              </span>
              <h2 className="mt-6 text-4xl font-semibold tracking-tight text-paper sm:text-5xl lg:text-6xl">
                You decide how much it is allowed to do.
              </h2>
            </div>
          </ScrollReveal>

          <div className="mt-16 grid grid-cols-1 gap-px border border-white/10 bg-white/10 md:grid-cols-3">
            {[
              { tag: "Default", tagColor: "#5c5f66", accentColor: "#5c5f66", name: "Observe Only", body: "Detects incidents and writes an evidence report. It alerts you and changes nothing." },
              { tag: "Recommended", tagColor: "#0f7a3d", accentColor: "#0f7a3d", name: "Approval Required", body: "Detects a likely regression and sends a rollback recommendation. You approve it." },
              { tag: "Opt in", tagColor: "#a15c00", accentColor: "#a15c00", name: "Auto-Recover", body: "Performs a rollback on its own, but only when every strict safety rule is met." }
            ].map((m, i) => (
              <ScrollReveal key={m.name} delay={i * 150}>
                <div className="relative bg-ink p-10">
                  <div
                    className="absolute inset-x-0 top-0 h-[3px]"
                    style={{ backgroundColor: m.accentColor }}
                  />
                  <span
                    className="font-mono text-[12px] uppercase tracking-widest"
                    style={{ color: m.tagColor }}
                  >
                    {m.tag}
                  </span>
                  <h3 className="mt-6 text-2xl font-medium text-paper">{m.name}</h3>
                  <p className="mt-4 text-lg leading-relaxed text-paper/60">{m.body}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* S7: Closing CTA */}
      <section className="bg-ink">
        <div className="mx-auto max-w-[1200px] px-6 py-32 text-center">
          <ScrollReveal>
            <span className="font-mono text-[13px] uppercase tracking-widest text-paper/50">
              Free forever
            </span>
            <h2 className="mt-6 text-4xl font-semibold tracking-tight text-paper sm:text-5xl lg:text-[clamp(3rem,5vw,4.5rem)]">
              Bring StackCircuit365 to<br className="hidden sm:block" /> your next deploy.
            </h2>
            <p className="mx-auto mt-8 max-w-xl text-xl leading-relaxed text-paper/60">
              Connect one GitHub repo and one Vercel project. See your production
              status in minutes. No paid tiers.
            </p>
          </ScrollReveal>

          <ScrollReveal delay={400}>
            <div className="mx-auto mt-12 flex max-w-md flex-col gap-3 sm:flex-row sm:justify-center">
              <a
                href="https://www.npmjs.com/package/stackcircuit365"
                target="_blank"
                rel="noreferrer"
                className="bg-paper px-8 py-4.5 font-mono text-[14px] uppercase tracking-widest text-ink"
              >
                View on npm
              </a>
              <a
                href="https://github.com/codehost-commit/stackcircuit365"
                target="_blank"
                rel="noreferrer"
                className="border border-paper/40 px-8 py-4.5 font-mono text-[14px] uppercase tracking-widest text-paper"
              >
                View on GitHub
              </a>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={600}>
            <div className="mt-20">
              <Logo />
            </div>
            <p className="mt-5 font-mono text-[12px] text-paper/40">
              stackcircuit.dev
            </p>
          </ScrollReveal>
        </div>
      </section>
    </div>
  );
}
