import type { Metadata } from "next";
import Dashboard from "@/components/Dashboard";

export const metadata: Metadata = {
  title: "Dashboard",
  description:
    "Your StackCircuit365 dashboard: production status, incidents, deploys, policy, alerts, and settings."
};

export default function DashboardPage() {
  return <Dashboard />;
}
