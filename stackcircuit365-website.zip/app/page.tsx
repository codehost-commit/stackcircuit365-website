import Link from "next/link";
import Countdown from "@/components/Countdown";
import IncidentTimeline from "@/components/IncidentTimeline";
import AudienceSplit from "@/components/AudienceSplit";
import ScrollReveal from "@/components/ScrollReveal";
import CountUp from "@/components/CountUp";
import VideoPlayer from "@/components/VideoPlayer";

const modes = [
  {
    tag: "Default",
    tagColor: "#5c5f66",
    accentColor: "#5c5f66",
    name: "Observe Only",
    body: "Detects incidents and writes an evidence report. It alerts you and changes nothing. This is where every account starts."
  },
  {
    tag: "Recommended",
    tagColor: "#0f7a3d",
    accentColor: "#0f7a3d",
    name: "Approval Required",
    body: "Detects a likely regression and sends a rollback recommendation. You approve it in the dashboard, or later from Slack."
  },
  {
    tag: "Opt in",
    tagColor: "#a15c00",
    accentColor: "#a15c00",
    name: "Auto-Recover",
    body: "Performs a rollback on its own, but only when every strict safety rule is met. Off until you turn it on, and only after real testing."
  }
];

const isNot = [
  "Not a generic uptime monitor",
  "Not a full observability platform",
  "Not a replacement for Sentry or Datadog",
  "Not an enterprise incident-management suite",
  "Not an AI coding chatbot"
];

const is = [
  "A release-recovery tool for teams that ship often",
  "Built for GitHub, Vercel, Next.js, and TypeScript",
  "Made for one to twenty engineers with no dedicated SRE",
  "Focused on the minutes right after a deploy"
];

const stats: [string, string][] = [
  ["Under 90s", "to detect a hard outage"],
  ["Under 3 min", "to verified recovery on clear cases"],
  ["Zero", "unsafe automated actions, by design"]
];

export default function Home() {
  return (
    <div>
      {/* --- Hero: full viewport, centered --- */}
      <section className="relative flex min-h-[100svh] items-center border-b border-line">
        <div className="mx-auto w-full max-w-[1200px] px-6 py-32 lg:py-40">
          <div className="mx-auto max-w-4xl text-center">
            <ScrollReveal>
              <div className="inline-flex items-center gap-2 border border-line bg-card px-4 py-2">
                <span className="h-2 w-2 bg-signal" aria-hidden="true" />
                <span className="font-mono text-[12px] uppercase tracking-widest text-muted">
                  Shipping Sep 4, 2026
                </span>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={100}>
              <h1 className="mt-10 text-[clamp(2.5rem,6vw,5.5rem)] font-semibold leading-[1.04] tracking-tight text-ink">
                Every release has a safety circuit.
              </h1>
            </ScrollReveal>

            <ScrollReveal delay={200}>
              <p className="mx-auto mt-8 max-w-2xl text-xl leading-relaxed text-muted sm:text-2xl sm:leading-relaxed">
                StackCircuit365 watches your GitHub to Vercel deployments. When a
                release breaks production, it isolates the deploy, rolls back to your
                last verified version, and writes the report. Free forever.
              </p>
            </ScrollReveal>

            <ScrollReveal delay={300}>
              <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
                <Link
                  href="#access"
                  className="bg-ink px-8 py-4 font-mono text-[14px] uppercase tracking-widest text-paper"
                >
                  Protect my app
                </Link>
                <a
                  href="https://www.npmjs.com/package/stackcircuit365"
                  target="_blank"
                  rel="noreferrer"
                  className="border border-ink px-8 py-4 font-mono text-[14px] uppercase tracking-widest text-ink"
                >
                  View on npm
                </a>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={400}>
              <div className="mx-auto mt-12 max-w-md">
                <Countdown />
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Trust strip: "Built for" */}
      <section className="border-b border-line bg-card">
        <div className="mx-auto flex max-w-[1200px] flex-wrap items-center justify-center gap-x-14 gap-y-4 px-6 py-8">
          {["GitHub", "Vercel", "Next.js", "TypeScript", "Node.js"].map((t) => (
            <span
              key={t}
              className="font-mono text-[13px] uppercase tracking-widest text-muted/60"
            >
              {t}
            </span>
          ))}
        </div>
      </section>

      {/* Video showcase */}
      <section className="border-b border-line bg-ink">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <ScrollReveal>
            <div className="mx-auto max-w-3xl text-center">
              <span className="font-mono text-[13px] uppercase tracking-widest text-signal">
                See it in action
              </span>
              <h2 className="mt-6 text-4xl font-semibold tracking-tight text-paper sm:text-5xl lg:text-6xl">
                From deploy to recovery in under three minutes.
              </h2>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={200}>
            <div className="mt-16">
              <VideoPlayer />
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Production status panel */}
      <section className="border-b border-line">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <div className="grid grid-cols-1 gap-16 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
            <ScrollReveal>
              <div>
                <span className="font-mono text-[13px] uppercase tracking-widest text-signal">
                  Live status
                </span>
                <h2 className="mt-6 text-4xl font-semibold tracking-tight text-ink sm:text-5xl">
                  Your production health, always visible.
                </h2>
                <p className="mt-6 max-w-xl text-xl leading-relaxed text-muted">
                  Every deploy, every health check, every recovery decision in one
                  place. The panel updates in real time so you know exactly where your
                  app stands.
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={200} distance={40}>
              <div className="border border-line bg-card">
                <div className="flex items-center justify-between border-b border-line2 px-5 py-3">
                  <span className="font-mono text-[13px] text-ink">
                    production // stackcircuit.dev
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="h-2.5 w-2.5 bg-signal" aria-hidden="true" />
                    <span className="font-mono text-[12px] uppercase tracking-widest text-signal">
                      Healthy
                    </span>
                  </div>
                </div>
                <div className="h-1 bg-signal" />
                <dl className="divide-y divide-line2 font-mono text-[14px]">
                  {[
                    ["status", "HEALTHY // 12 of 12 checks passing"],
                    ["deploy", "dpl_9f21c  promoted 4m ago"],
                    ["commit", 'a1b2c3d  "fix: cache-control header"'],
                    ["latency", "p95 210ms // no error spike"],
                    ["known good", "dpl_9f21c  verified and locked"]
                  ].map(([k, v]) => (
                    <div
                      key={k}
                      className="grid grid-cols-[7.5rem_1fr] gap-3 px-5 py-3.5"
                    >
                      <dt className="pt-0.5 text-[11px] uppercase tracking-widest text-muted">
                        {k}
                      </dt>
                      <dd className="text-ink">{v}</dd>
                    </div>
                  ))}
                </dl>
                <div className="border-t border-line2 px-5 py-3.5">
                  <span className="font-mono text-[12px] text-muted">
                    Next check in 41s. Post-deploy window closes in 9m.
                  </span>
                </div>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Audience split */}
      <section id="how" className="scroll-mt-20 border-b border-line">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <ScrollReveal>
            <div className="mx-auto max-w-3xl text-center">
              <h2 className="text-4xl font-semibold tracking-tight text-ink sm:text-5xl">
                The minute after you ship.
              </h2>
              <p className="mx-auto mt-6 max-w-2xl text-xl leading-relaxed text-muted">
                That is when releases break, and when StackCircuit365 goes to work.
                Pick the walkthrough that fits how you build.
              </p>
            </div>
          </ScrollReveal>
          <ScrollReveal delay={200}>
            <div className="mt-16">
              <AudienceSplit />
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Recovery modes */}
      <section id="modes" className="scroll-mt-20 border-b border-line bg-ink">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <ScrollReveal>
            <div className="mx-auto max-w-3xl text-center">
              <span className="font-mono text-[13px] uppercase tracking-widest text-signal">
                Recovery modes
              </span>
              <h2 className="mt-6 text-4xl font-semibold tracking-tight text-paper sm:text-5xl lg:text-6xl">
                You decide how much it is allowed to do.
              </h2>
              <p className="mx-auto mt-6 max-w-2xl text-xl leading-relaxed text-paper/60">
                Start in Observe Only and move up as you learn to trust it. Nothing
                touches production until your policy says it can.
              </p>
            </div>
          </ScrollReveal>

          <div className="mt-16 grid grid-cols-1 gap-px border border-white/10 bg-white/10 md:grid-cols-3">
            {modes.map((m, i) => (
              <ScrollReveal key={m.name} delay={i * 120}>
                <div className="relative bg-ink p-10">
                  <div
                    className="absolute inset-x-0 top-0 h-[3px]"
                    style={{ backgroundColor: m.accentColor }}
                  />
                  <span
                    className="font-mono text-[12px] uppercase tracking-widest"
                    style={{ color: m.tagColor }}
                  >
                    {m.tag}
                  </span>
                  <h3 className="mt-6 text-2xl font-medium text-paper">{m.name}</h3>
                  <p className="mt-4 text-lg leading-relaxed text-paper/60">
                    {m.body}
                  </p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      {/* Incident demo */}
      <section className="border-b border-line">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <div className="grid grid-cols-1 gap-16 lg:grid-cols-[1fr_1.2fr] lg:items-start">
            <ScrollReveal>
              <div>
                <span className="font-mono text-[13px] uppercase tracking-widest text-signal">
                  Incident replay
                </span>
                <h2 className="mt-6 text-4xl font-semibold tracking-tight text-ink sm:text-5xl">
                  Watch a real regression get contained.
                </h2>
                <p className="mt-6 max-w-xl text-xl leading-relaxed text-muted">
                  This is a simulated timeline of a bad deploy caught in Approval
                  Required mode. Step through it to see what your team would receive.
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={200}>
              <div>
                <IncidentTimeline />
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Is / Is not */}
      <section className="border-b border-line bg-card">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <ScrollReveal>
            <div className="mx-auto max-w-3xl text-center">
              <span className="font-mono text-[13px] uppercase tracking-widest text-signal">
                Scope
              </span>
              <h2 className="mt-6 text-4xl font-semibold tracking-tight text-ink sm:text-5xl">
                One narrow job, done properly.
              </h2>
            </div>
          </ScrollReveal>

          <ScrollReveal delay={200}>
            <div className="mt-16 grid grid-cols-1 gap-px border border-line bg-line md:grid-cols-2">
              <div className="relative bg-card p-10 md:p-12">
                <div className="absolute inset-y-0 left-0 w-[3px] bg-signal" />
                <p className="font-mono text-[13px] uppercase tracking-widest text-signal">
                  What it is
                </p>
                <ul className="mt-8 flex flex-col gap-6">
                  {is.map((t) => (
                    <li key={t} className="flex gap-4 text-lg text-ink">
                      <span
                        className="mt-2.5 h-2.5 w-2.5 shrink-0 bg-signal"
                        aria-hidden="true"
                      />
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="relative bg-card p-10 md:p-12">
                <div className="absolute inset-y-0 left-0 w-[3px] bg-line" />
                <p className="font-mono text-[13px] uppercase tracking-widest text-alert">
                  What it is not
                </p>
                <ul className="mt-8 flex flex-col gap-6">
                  {isNot.map((t) => (
                    <li key={t} className="flex gap-4 text-lg text-muted">
                      <span
                        className="mt-2.5 h-2.5 w-2.5 shrink-0 bg-line"
                        aria-hidden="true"
                      />
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* Safety + reliability */}
      <section className="border-b border-line bg-ink">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <div className="grid grid-cols-1 gap-16 lg:grid-cols-[1fr_1fr]">
            <ScrollReveal>
              <div>
                <span className="font-mono text-[13px] uppercase tracking-widest text-signal">
                  Safety first
                </span>
                <h2 className="mt-6 text-4xl font-semibold tracking-tight text-paper sm:text-5xl">
                  The AI never decides to change production.
                </h2>
                <p className="mt-6 text-xl leading-relaxed text-paper/70">
                  A deterministic policy engine controls every rollback and every
                  write. The AI reads evidence, connects a failure to a commit, and
                  drafts the report a human reviews. It stops at the door of any
                  database migration, auth change, billing path, secret, or
                  anything it is not sure about.
                </p>
                <p className="mt-5 text-xl leading-relaxed text-paper/70">
                  StackCircuit365 must be safe before it is impressive. That rule
                  comes before every feature on the roadmap.
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={200}>
              <div className="lg:pt-16">
                <div className="border border-white/10">
                  {stats.map(([stat, label], i) => (
                    <div
                      key={stat}
                      className="border-b border-white/10 px-8 py-10 last:border-b-0"
                    >
                      <CountUp text={stat} delay={i * 250} variant="dark" />
                      <div className="mt-3 text-lg text-paper/60">{label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* CTA: Free forever */}
      <section id="access" className="scroll-mt-20 bg-ink">
        <div className="mx-auto max-w-[1200px] px-6 py-32">
          <div className="mx-auto max-w-3xl text-center">
            <ScrollReveal>
              <span className="font-mono text-[13px] uppercase tracking-widest text-paper/50">
                Free forever
              </span>
              <h2 className="mt-6 text-4xl font-semibold tracking-tight text-paper sm:text-5xl lg:text-6xl">
                Bring StackCircuit365 to your next deploy.
              </h2>
              <p className="mx-auto mt-8 max-w-xl text-xl leading-relaxed text-paper/60">
                The public launch is September 4, 2026. StackCircuit365 is free, with
                no paid tiers. Connect one GitHub repo and one Vercel project, and see
                your production status in minutes.
              </p>
            </ScrollReveal>

            <ScrollReveal delay={200}>
              <div className="mx-auto mt-12 flex max-w-md flex-col gap-3">
                <a
                  href="https://www.npmjs.com/package/stackcircuit365"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-paper px-8 py-4.5 text-center font-mono text-[14px] uppercase tracking-widest text-ink"
                >
                  View the package on npm
                </a>
                <a
                  href="https://github.com/codehost-commit/stackcircuit365"
                  target="_blank"
                  rel="noreferrer"
                  className="border border-paper/40 px-8 py-4.5 text-center font-mono text-[14px] uppercase tracking-widest text-paper"
                >
                  View the source on GitHub
                </a>
                <p className="mt-2 font-mono text-[12px] leading-relaxed text-paper/40">
                  Free forever. One repo, one Vercel project, one production URL,
                  standard checks.
                </p>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>
    </div>
  );
}
